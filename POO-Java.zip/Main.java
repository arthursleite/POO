import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {

        String nome = JOptionPane.showInputDialog("Digite seu nome:");
        String modeloCarro = JOptionPane.showInputDialog("Digite o modelo do seu carro:");
        String anoCarro = JOptionPane.showInputDialog("Digite o ano do seu carro:");
        int anoCarroInt = Integer.parseInt(anoCarro);
        String valorCarro = JOptionPane.showInputDialog("Digite o valor do seu carro");
        double valorCarroDouble = Double.parseDouble(valorCarro);

        JOptionPane.showMessageDialog(null, "Nome: " + nome
                + "\nModelo: " + modeloCarro
                + "\nAno do carro: " + anoCarro
                + "\nValor do carro: " + valorCarro);

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite seu nome:");
        String nomeDono = sc.nextLine();
        System.out.println("Digite o nome do pet:");
        String nomePet = sc.nextLine();
        System.out.println("Digite a idade do pet:");
        int idadePet = sc.nextInt();
        System.out.println("Digite o peso do pet:");
        double pesoPet = sc.nextDouble();
        sc.nextLine();
        System.out.println("Digite a raca do pet:");
        String racaPet = sc.nextLine();

        System.out.println("Dono: " + nomeDono
                + "\nNome do pet: " + nomePet
                + "\nIdade do pet: " + idadePet
                + "\nPeso do pet: " + pesoPet
                + "\nRaca do pet: " + racaPet);

        sc.close();
    }

}
