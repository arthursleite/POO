package newpackage2;

import java.util.Scanner;

class Exercicio_Basico_1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double salario, comissao, valorVendas, valorPorVenda, salarioFinal, porcentagem, valorPorcentagem = 5;
        int numVendas;

        System.out.println("Digite o número de vendas");
        numVendas = sc.nextInt();
        System.out.println("Digite o valor total de vendas");
        valorVendas = sc.nextDouble();
        System.out.println("Digite o salário fixo");
        salario = sc.nextDouble();
        System.out.println("Digite o valor recebido por venda");
        valorPorVenda = sc.nextDouble();
        comissao = valorPorVenda * numVendas;
        porcentagem = (valorPorcentagem / 100) * valorVendas;
        salarioFinal = salario + comissao + porcentagem;
        System.out.println("O salário final é: " + salarioFinal);

        sc.close();
    }
}
