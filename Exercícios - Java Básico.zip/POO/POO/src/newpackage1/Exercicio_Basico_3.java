package newpackage1;

import java.util.Scanner;

public class Exercicio_Basico_3 {

    public static void main(String[] args) {
        String sexo, corOlho, corCabelo;
        int idade;
        double salario, porcentagem = 0;
        int numeroIndividuos = 0, resto = 0, totalIndividuos = 0;

        Scanner sc = new Scanner(System.in);

        do {
            do {
                System.out.println("Digite o sexo: ");
                sexo = sc.nextLine();
            } while (!(sexo.equals("m") || sexo.equals("f")));

            do {
                System.out.println("Digite a cor dos olhos: ");
                corOlho = sc.nextLine();
            } while (!(corOlho.equals("a") || corOlho.equals("v") || corOlho.equals("c") || corOlho.equals("p")));

            do {
                System.out.println("Digite a cor dos cabelos: ");
                corCabelo = sc.nextLine();
            } while (!(corCabelo.equals("l") || corCabelo.equals("c") || corCabelo.equals("p") || corCabelo.equals("r")));

            do {
                System.out.println("Digite a idade: ");
                idade = sc.nextInt();
                if (idade == -1) {
                    break;
                }
            } while (!(idade >= 10 && idade <= 100));
            
            if (idade == -1) {
                    break;
                }
            
            do {
                System.out.println("Digite o salário: ");
                salario = sc.nextDouble();
            } while (salario < 0);
            sc.nextLine();
            
            if(sexo.equals("f") && corOlho.equals("c") && corCabelo.equals("c") && (idade >= 18 && idade <= 35)) {
                numeroIndividuos ++;
            } else {
                resto ++;
            }
            totalIndividuos = numeroIndividuos + resto;
        } while (idade != -1);

        porcentagem = ((double) numeroIndividuos / totalIndividuos) * 100;
        System.out.println("A porcentagem é de: " + porcentagem);
        
        sc.close();
    }
}