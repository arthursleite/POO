package newpackage;

import java.util.Scanner;

public class Exercicio_Basico_2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int[] prato = {180, 230, 250, 350};
        int[] sobremesa = {75, 110, 170, 200};
        int[] bebida = {20, 70, 100, 65};

        System.out.println("Digite o prato de 1 a 4:");
        int opcaoPrato = sc.nextInt() - 1;
        System.out.println("Digite a sobremesa de 1 a 4:");
        int opcaoSobremesa = sc.nextInt() - 1;
        System.out.println("Digite a bebida de 1 a 4:");
        int opcaoBebida = sc.nextInt() - 1;

        int valorFinal = prato[opcaoPrato] + sobremesa[opcaoSobremesa] + bebida[opcaoBebida];
        System.out.println(valorFinal);

        sc.close();
    }
}
